This is an example of using [Margo][] with the [Margo GitHub Action][Margo-GHA].

[Margo]:  https://github.com/integer32llc/margo
[Margo-GHA]:  https://github.com/integer32llc/margo-actions
